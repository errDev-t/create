Config = {
    startingMSG = 'testing {{projectName}}'
}