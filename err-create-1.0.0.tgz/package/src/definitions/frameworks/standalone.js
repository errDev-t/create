export const standalone = {};
